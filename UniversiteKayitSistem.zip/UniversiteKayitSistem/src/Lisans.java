public class Lisans extends Ogrenci{
    private int derslerSayisi;
    private Ortalama ort = new Ortalama();

    public Lisans() {
    }


    public Lisans(String ad, String soyad, String ID, String mail, String kimlikTC,int ogrenmeSuresi,int derslerSayisi,int vizeNotu, int finalNotu, double GNO) {
        super(ad, soyad, ID, mail, kimlikTC, ogrenmeSuresi, vizeNotu, finalNotu, GNO);
        this.derslerSayisi = derslerSayisi;
    }

    @Override
    public int getVizeNotu() {
        if(vizeNotu < 0 || vizeNotu > 100)
            return -1;
        return vizeNotu;
    }
    @Override
    public int getFinalNotu() {
        if(finalNotu < 0 || finalNotu > 100)
            return -1;
        return finalNotu;
    }

    @Override
    public double getGNO() {
        if(GNO < 0 || GNO > 4)
            return -1;
        return GNO;
    }

    public int getDerslerSayisi() {
        return derslerSayisi;
    }

    public void setDerslerSayisi(int derslerSayisi) {
        this.derslerSayisi = derslerSayisi;
    }

    @Override
    void ortalamaHesaplama(int vize, int Final) {
        System.out.println(ort.ortalamaHesaplama(vize,Final));
    }
    @Override
    protected double ortalamaHesaplama() {
        return ort.ortalamaHesaplama(vizeNotu,finalNotu);
    }

    @Override
    public String toString() {
        return "\n\n"+"Lisans Öğrenci: "+ '\n' +
                info +
                "Vize Notu : " + vizeNotu + '\n' +
                "Final Notu :" + finalNotu + '\n' +
                "GNO : " + GNO + '\n' +
                "Ogrenme Suresi :" + ogrenmeSuresi + '\n' +
                "Ortalama : " + ortalamaHesaplama() + '\n' +
                "Dersler sayısı :" + derslerSayisi;
    }
}
