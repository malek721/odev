import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.naming.Name;
import javax.swing.*;
public class UniversiteKayitEkrani extends JFrame implements ActionListener {
    JLabel background;
    ImageIcon img;
    JTextField ad;
    JTextField soyad;
    JTextField kemlikNo;
    JTextField idField;
    JTextField mail;
    JButton ogrBtn;
    JButton prsBtn;
    static String fName;
    static String lName;
    static String No;
    static String id;
    static String email;
    JPanel panel;
    static ArrayList<kullaniciler> kullaniciler = new ArrayList<>();
    UniversiteKayitEkrani(){
        img = new ImageIcon("goldBackground.jpg");
        background = new JLabel();
        background.setIcon(img);
        background.setSize(400,400);
        panel =new JPanel();
        JLabel UniName = new JLabel("İnönü Üniversite Kayıt Sistemi");
        JLabel firstName = new JLabel("Ad");
        JLabel lastName = new JLabel("Soyad");
        JLabel TCNo = new JLabel("TC Kimlik NO");
        JLabel ID = new JLabel("ID");
        JLabel Mail = new JLabel("Mail");
        ad = new JTextField();
        soyad = new JTextField();
        kemlikNo = new JTextField();
        idField = new JTextField();
        mail = new JTextField();
        ogrBtn = new JButton("Öğrenci");
        prsBtn = new JButton("Personel");
        ogrBtn.addActionListener(this);
        prsBtn.addActionListener(this);
        UniName.setFont(new Font("Arial",Font.BOLD,20));
        UniName.setForeground(new Color(255,255,255));
        UniName.setBounds(50,0,300,100);
        ogrBtn.setBounds(110,270,100,30);
        prsBtn.setBounds(220,270,100,30);
        ogrBtn.setFocusPainted(false);
        prsBtn.setFocusPainted(false);
        firstName.setFont(new Font("Arial",Font.BOLD,15));
        firstName.setBounds(5,75,25,50);
        firstName.setForeground(new Color(255,255,255));
        ad.setBounds(110,90,100,20);
        lastName.setFont(new Font("Arial",Font.BOLD,15));
        lastName.setBounds(220,75,60,50);
        lastName.setForeground(new Color(255,255,255));
        soyad.setBounds(270,90,100,20);
        TCNo.setFont(new Font("Arial",Font.BOLD,15));
        TCNo.setBounds(5,125,100,50);
        TCNo.setForeground(new Color(255,255,255));
        kemlikNo.setBounds(110,135,100,20);
        ID.setFont(new Font("Arial",Font.BOLD,15));
        ID.setBounds(5,180,25,20);
        ID.setForeground(new Color(255,255,255));
        idField.setBounds(110,180,100,20);
        Mail.setFont(new Font("Arial",Font.BOLD,15));
        Mail.setBounds(5,220,35,20);
        Mail.setForeground(new Color(255,255,255));
        mail.setBounds(110,220,100,20);
        setTitle("Kayıt Sistem");
        setResizable(false);
        setVisible(true);
        setSize(400,350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(panel);
        setContentPane(panel);
        panel.setLayout(null);
        panel.setVisible(true);
        panel.setSize(400,350);
        background.add(UniName);
        background.add(ogrBtn);
        background.add(prsBtn);
        background.add(firstName);
        background.add(ad);
        background.add(lastName);
        background.add(soyad);
        background.add(TCNo);
        background.add(kemlikNo);
        background.add(ID);
        background.add(idField);
        background.add(mail);
        background.add(Mail);
        panel.add(background);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==ogrBtn){
            new OgrenciKayitEkrani();
            fName = ad.getText();
            lName = soyad.getText();
            No = kemlikNo.getText();
            id = idField.getText();
            email = mail.getText();
            dispose();
        }
        if (e.getSource()==prsBtn){
            new PersonalKayitEkrani();
            fName = ad.getText();
            lName = soyad.getText();
            No = kemlikNo.getText();
            id = idField.getText();
            email = mail.getText();
            dispose();
        }
    }
    public static void main(String args[]){
        new UniversiteKayitEkrani();
    }
}