public interface Personel extends kullaniciler {
    int maasHesaplama();
}