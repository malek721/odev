import java.util.ArrayList;

public class Universite {
    private final String Ad = "İnönü Üniversitesi";
    private final String il = "Malatya";
    private ArrayList<kullaniciler> kullaniciler;

    public Universite() {
    }

    public Universite(ArrayList<kullaniciler> kullaniciler) {
        this.kullaniciler = kullaniciler;
    }

    @Override
    public String toString() {
        return "Üniversite : " + Ad +'\n'+
                "il : " + il +
                kullaniciler.toString().replace('[',' ').replace(',',' ').replace(']',' ') ;
    }

    public String bilgiler() {
        return kullaniciler.toString().replace('[',' ').replace(',',' ').replace(']',' ');
    }

}

