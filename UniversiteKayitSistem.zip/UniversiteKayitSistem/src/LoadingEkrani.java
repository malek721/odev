import javax.swing.*;
import java.awt.*;

public class LoadingEkrani extends JFrame {
    JPanel loadPane;
    JLabel loadPercent;
    JLabel loading;
    JLabel background;
    JProgressBar loadBar;
    ImageIcon img;
    LoadingEkrani(){
        img = new ImageIcon("goldBackground.jpg");
        background = new JLabel();
        background.setIcon(img);
        background.setSize(400,400);
        loadPane = new JPanel();
        loadPercent = new JLabel();
        loading = new JLabel();
        loadBar = new JProgressBar();
        loading.setBounds(130,100,200,50);
        loading.setFont(new Font("Arial",Font.BOLD,25));
        loading.setForeground(new Color(255,255,255));
        loadPercent.setText("0%");
        loadPercent.setBounds(180,150,70,40);
        loadPercent.setFont(new Font("Arial",Font.BOLD,20));
        loadPercent.setForeground(new Color(255,255,255));
        loadBar.setBounds(100,200,200,20);
        setSize(400,400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setResizable(false);
        add(loadPane);
        setContentPane(loadPane);
        loadPane.setLayout(null);
        loadPane.setVisible(true);
        loadPane.add(background);
        background.add(loadPercent);
        background.add(loadBar);
        background.add(loading);
        loadPane.setSize(400,400);

    }
}
