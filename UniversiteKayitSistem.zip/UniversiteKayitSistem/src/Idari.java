public class Idari implements Personel{
    private int calismaGunler;
    private int BaslamisYili;
    private String gorev;
    private PersonalInfo info;
    private Maas ms = new Maas();

    public Idari() {
    }

    public Idari(String ad, String soyad, String ID, String mail, String kimlikTC,int BaslamisYili, String gorev,int calismaGunler) {
        if(calismaGunler < 0 || calismaGunler > 31)
            this.calismaGunler = -1;
        else
            this.calismaGunler = calismaGunler;
        if(BaslamisYili > 2022)
            this.BaslamisYili = -1;
        else
            this.BaslamisYili = BaslamisYili;
        this.info = new PersonalInfo(ad,soyad,ID,mail,kimlikTC);
        this.gorev = gorev;
    }

    public int getCalismaGunler() {
        if(calismaGunler < 0 || calismaGunler > 31)
            return -1;
        else
            return calismaGunler;
    }

    public void setCalismaGunler(int calismaGunler) {
        this.calismaGunler=calismaGunler;
    }

    public int getBaslamisYili() {
        if(BaslamisYili > 2022)
            return -1;
        else
            return BaslamisYili;
    }

    public void setBaslamisYili(int BaslamisYili) {this.BaslamisYili = BaslamisYili;}

    public String getGorev() {
        return gorev;
    }

    public void setGorev(String gorev) {
        this.gorev = gorev;
    }


    @Override
    public int maasHesaplama() {
        return ms.idariMaas(calismaGunler);
    }

    @Override
    public String toString() {
        return "\n\n"+"İdari Personel: "+'\n'+
                info +
                "Maaş : " + maasHesaplama() +'\n'+
                "Çalışma Günleri : " + calismaGunler +'\n'+
                "Görev : " + gorev;
    }
}
